document.querySelector('.v-btn-toggle input').addEventListener('click', () => {
    document.querySelector('.v-navbar ul').classList.toggle('show')
})
document.querySelector('.v-btn-toggle input').addEventListener('click', () => {
    document.querySelector('.v-navbar-fixed ul').classList.toggle('show')
})